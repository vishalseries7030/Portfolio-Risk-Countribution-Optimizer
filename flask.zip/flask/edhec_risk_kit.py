# edhec_risk_kit.py
import pandas as pd
import numpy as np
from scipy.optimize import minimize

def get_ind_file(filetype="rets", nind=49):
    # Load and return the industry returns or other files based on filetype
    if filetype == "rets":
        # Load returns data (example placeholder, replace with actual data loading logic)
        return pd.read_csv('path_to_returns_data.csv', index_col=0, parse_dates=True).iloc[:, :nind]
    # Add logic for other file types if needed
    pass

def get_ind_market_caps(nind=49, weights=False):
    # Load and return the industry market caps
    # Example placeholder, replace with actual data loading logic
    return pd.read_csv('path_to_market_caps_data.csv', index_col=0, parse_dates=True).iloc[:, :nind]

def annualize_rets(r, periods_per_year):
    compounded_growth = (1 + r).prod()
    n_periods = r.shape[0]
    return compounded_growth**(periods_per_year/n_periods) - 1

def sample_cov(r):
    return r.cov()

def minimize_volatility(ann_rets, cov_matrix):
    n = ann_rets.shape[0]
    init_guess = np.repeat(1/n, n)
    bounds = ((0.0, 1.0),) * n

    def portfolio_vol(weights, cov_matrix):
        return (weights.T @ cov_matrix @ weights)**0.5

    constraints = ({'type': 'eq', 'fun': lambda weights: np.sum(weights) - 1})
    result = minimize(portfolio_vol, init_guess, args=(cov_matrix,), method='SLSQP', options={'disp': False}, constraints=constraints, bounds=bounds)
    return result.x

def portfolio_risk_contributions(weights, cov_matrix):
    total_portfolio_variance = (weights.T @ cov_matrix @ weights)
    risk_contributions = weights * (cov_matrix @ weights) / total_portfolio_variance
    return pd.Series(risk_contributions, index=cov_matrix.index)

def enc(weights):
    return np.exp(-np.sum(weights * np.log(weights)))

def encb(risk_contributions):
    return np.exp(-np.sum(risk_contributions * np.log(risk_contributions)))

def portfolio_risk_contrib_optimizer(target_risk, cov_matrix):
    n = len(target_risk)
    init_guess = np.repeat(1/n, n)
    bounds = ((0.0, 1.0),) * n

    def objective(weights):
        portfolio_var = weights.T @ cov_matrix @ weights
        risk_contributions = weights * (cov_matrix @ weights) / portfolio_var
        return ((risk_contributions - target_risk)**2).sum()

    constraints = ({'type': 'eq', 'fun': lambda weights: np.sum(weights) - 1})
    result = minimize(objective, init_guess, method='SLSQP', bounds=bounds, constraints=constraints)
    return pd.Series(result.x, index=target_risk.index)

def weight_ew(returns):
    n = returns.shape[1]
    return pd.Series(1/n, index=returns.columns)

def weight_cw(returns, cap_ws):
    return cap_ws

def risk_parity_weights(cov_matrix):
    n = cov_matrix.shape[0]
    init_guess = np.repeat(1/n, n)
    bounds = ((0.0, 1.0),) * n

    def objective(weights):
        risk_contributions = weights * (cov_matrix @ weights)
        risk_parity_target = np.repeat(1/n, n) * np.sum(risk_contributions)
        return ((risk_contributions - risk_parity_target)**2).sum()

    constraints = ({'type': 'eq', 'fun': lambda weights: np.sum(weights) - 1})
    result = minimize(objective, init_guess, method='SLSQP', bounds=bounds, constraints=constraints)
    return pd.Series(result.x, index=cov_matrix.index)

def backtest_weight_scheme(returns, window, weight_scheme, **kwargs):
    n_periods = returns.shape[0]
    n_assets = returns.shape[1]
    weights = np.zeros((n_periods, n_assets))
    for i in range(window, n_periods):
        rets_window = returns.iloc[i-window:i]
        weights[i] = weight_scheme(rets_window, **kwargs)
    weights = pd.DataFrame(weights, index=returns.index, columns=returns.columns)
    rets_portfolio = (weights.shift() * returns).sum(axis=1)
    return rets_portfolio

def summary_stats(returns):
    ann_rets = returns.aggregate(annualize_rets, periods_per_year=12)
    ann_vol = returns.aggregate(np.std) * np.sqrt(12)
    ann_sharpe = ann_rets / ann_vol
    stats = pd.DataFrame({
        "Annualized Return": ann_rets,
        "Annualized Volatility": ann_vol,
        "Sharpe Ratio": ann_sharpe
    })
    return stats