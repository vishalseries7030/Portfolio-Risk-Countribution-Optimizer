# app.py
import pandas as pd
import numpy as np
import warnings
import json
from flask import Flask, request, jsonify
import sys
sys.path.insert(1, '/kaggle/input/edhec-investment-management-datasets')
import edhec_risk_kit as erk

warnings.filterwarnings("ignore")

app = Flask(__name__)

def optimize_portfolio(target_risk, amount, companies):
    # Load company returns and market caps
    ind_rets = erk.get_ind_file(filetype="rets", nind=len(companies))["2000":]
    ind_mkt_caps = erk.get_ind_market_caps(nind=len(companies), weights=True)["2000":]
    mat_cov = ind_rets.cov()

    # Portfolio optimization based on target risk contributions
    weights = erk.portfolio_risk_contrib_optimizer(target_risk, mat_cov)
    p_risk_contribs = erk.portfolio_risk_contributions(weights, mat_cov)
    ENC = erk.enc(weights)
    ENCB = erk.encb(p_risk_contribs)
    
    # Calculate the amount to be invested in each company
    investment = weights * amount

    return {
        "weights": weights.to_dict(),
        "risk_contributions": p_risk_contribs.to_dict(),
        "ENC": ENC,
        "ENCB": ENCB,
        "investment": investment.to_dict()
    }

@app.route('/optimize', methods=['POST'])
def optimize():
    data = request.get_json()
    risk_percentage = data.get('risk_percentage')
    amount = data.get('amount')

    # Example list of industries (using the same industries as in the original code)
    companies = ['Beer','Hlth','Fin','Rtail','Whlsl']

    # Normalize risk percentage to sum to 1
    total_risk = sum(risk_percentage)
    target_risk = pd.Series([r / total_risk for r in risk_percentage], index=companies)
    
    # Optimize portfolio
    result = optimize_portfolio(target_risk, amount, companies)
    
    return jsonify(result)

if __name__ == '_main_':
    app.run(debug=True)